import React from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { Header } from "../components/Header";
import { PrimaryButton } from "../components/PrimaryButton";
import { MenuItem } from "../components/MenuItem";
import { TodoBox } from "../components/TodoBox";
import { useAuth, useWishlist } from "../store/hooks";
import { TabScreenProps } from "../navigation/types";
import { colors } from "../theme";

export function AccountScreen({ navigation }: TabScreenProps<"Account">) {
  const { user, isLoggedIn, signOut } = useAuth();
  const { ids } = useWishlist();

  return (
    <View style={styles.container}>
      <Header title="👤 Tài khoản" />
      <ScrollView contentContainerStyle={styles.content}>
        {isLoggedIn && user ? (
          <View style={styles.profile}>
            <Text style={styles.avatar}>🙂</Text>
            <Text style={styles.name}>{user.name}</Text>
            <Text style={styles.email}>{user.email}</Text>
            {/* TODO BT9.4c: hiện SĐT (nếu có) + nút “✎ Chỉnh sửa” → navigation.navigate("EditProfile") */}
            <TodoBox id="BT9.4c">{"Hiện số điện thoại + nút Chỉnh sửa → màn EditProfile"}</TodoBox>
          </View>
        ) : (
          <View style={styles.profile}>
            <Text style={styles.avatar}>🔒</Text>
            <Text style={styles.name}>Bạn chưa đăng nhập</Text>
            <View style={styles.actions}>
              <PrimaryButton title="Đăng nhập" onPress={() => navigation.navigate("Login")} />
              <PrimaryButton title="Đăng ký" variant="outline" onPress={() => navigation.navigate("Register")} />
            </View>
          </View>
        )}

        <View style={styles.menu}>
          {/* TODO BT9.5f / BT9.3d: thêm 2 <MenuItem> — 🔔 Thông báo → "Notifications"; 🧾 Đơn hàng của tôi → "Orders" */}
          <TodoBox id="BT9.3d · BT9.5f">{"Thêm menu 🔔 Thông báo và 🧾 Đơn hàng của tôi"}</TodoBox>
          <MenuItem emoji="❤️" label="Danh sách yêu thích" hint={ids.length ? `${ids.length} sách` : undefined} onPress={() => navigation.navigate("Wishlist")} />
        </View>

        {isLoggedIn && (
          <View style={styles.actions}>
            <PrimaryButton title="Đăng xuất" variant="outline" onPress={signOut} />
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 16, gap: 14 },
  profile: { alignItems: "center", gap: 6, paddingVertical: 8 },
  avatar: { fontSize: 64 },
  name: { fontSize: 20, fontWeight: "800", color: colors.text },
  email: { color: colors.muted },
  menu: { gap: 8 },
  actions: { alignSelf: "stretch", gap: 10, marginTop: 6 },
});
